from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters
from config import TOKEN

user_lists = {}

def build_keyboard(items, checked):
    keyboard = []
    for i, item in enumerate(items):
        label = f"~{item}~" if checked[i] else item
        button = InlineKeyboardButton(label, callback_data=str(i))
        keyboard.append([button])
    return InlineKeyboardMarkup(keyboard)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Envía tu lista separada por líneas.")

async def handle_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    items = text.split('\n')
    checked = [False] * len(items)
    user_lists[update.effective_chat.id] = (items, checked)
    keyboard = build_keyboard(items, checked)
    await update.message.reply_text("Aquí está tu lista:", reply_markup=keyboard)

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    chat_id = query.message.chat.id
    index = int(query.data)
    if chat_id in user_lists:
        items, checked = user_lists[chat_id]
        checked[index] = not checked[index]
        user_lists[chat_id] = (items, checked)
        keyboard = build_keyboard(items, checked)
        await query.edit_message_reply_markup(reply_markup=keyboard)

def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_list))
    app.add_handler(CallbackQueryHandler(button_handler))
    print("Bot corriendo... Ctrl+C para detener.")
    app.run_polling()

if __name__ == "__main__":
    main()
