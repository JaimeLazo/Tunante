# Reemplaza esto con tu token real de @BotFather
TOKEN = "TU_TOKEN_DE_TELEGRAM"
