#!/bin/bash
echo "Instalando dependencias..."
pip3 install -r requirements.txt
echo "Iniciando bot..."
python3 bot.py
